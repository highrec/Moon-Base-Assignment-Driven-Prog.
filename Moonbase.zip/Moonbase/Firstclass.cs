﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Moonbase
{
    public partial class Firstclass : Form
    {
      
        public Firstclass(string from1)
        {
            InitializeComponent();
            textBox1tf1.Text = from1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormMain1 FM1 = new FormMain1(textBox1.Text);
            this.Hide();
            FM1.Show();
        }


        private void Firstclass_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                MessageBox.Show("This is the North Wing if the base.");
            }
            else if (radioButton2.Checked)
            {
                MessageBox.Show("This is the South wing of the base.");
            }
            else if (radioButton3.Checked)
            {
                MessageBox.Show("This is the West end of the base.");
            }
            else if (radioButton4.Checked)
            {
                MessageBox.Show("This is the East end of the base.");
            }
            else if (BonusRB.Checked)
            {
                MessageBox.Show("Now lets go inside of the rooms.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.BackgroundImage = Properties.Resources.Millennium_Falcon;
        }
    }
}
