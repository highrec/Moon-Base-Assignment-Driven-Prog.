﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Moonbase
{
    public partial class FormMain1 : Form
    {
        public string rmstr;
        public FormMain1(string from2 = "")
        {
            InitializeComponent();
            textBox4.Text = from2;
        }

        private void FormMain1_Load(object sender, EventArgs e)
        {

        }

        private void GB1_Enter(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Aboard ship");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            textBox1.Text = "Exterior Description";
            textBox1.ReadOnly = true;
            // textBox1.Enabled = false;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.Text = "Moon Surface";
            textBox2.ReadOnly = true;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            richTextBox1.ReadOnly = true;
            richTextBox1.Enabled = false;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            Image r2d2 = Image.FromFile("r2d2.jpg");
            pictureBox1.Image = r2d2;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            Image alienfamily = Image.FromFile("alien family.jpg");
            pictureBox1.Image = alienfamily;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

            Image luke = Image.FromFile("luke.jpg");
            pictureBox1.Image = luke;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

            Image Benkenobi = Image.FromFile("Benkenobi.jpg");
            pictureBox1.Image = Benkenobi;
        }


        private void button2_Click_1(object sender, EventArgs e)
        {
            Firstclass frs = new Firstclass(textBox5.Text);
            this.Hide();
            frs.Show();
        }


        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            this.BackgroundImage = Properties.Resources.Millennium_Falcon;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox3.Text, out int value))
            {
                MessageBox.Show("Your desitnaiton Number is valid");
            }
            else
            {
                MessageBox.Show(" Please enter a random number!");
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            this.BackgroundImage = Properties.Resources.Millennium_Falcon_room;
            this.rmstr = "Millemnium";
            richTextBox1.Text = "DDrere dfjgdrijetyipj";
            textBox2.Text = "Mellinum Room";
        }

    }
}
